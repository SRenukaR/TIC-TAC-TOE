package com.renuka.tictactoygame;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void buClick(View view) {
        Button buSelected=(Button)view;
        int callId=0;
        switch(buSelected.getId()){
            case R.id.button:
                callId=1;
                break;
            case R.id.button2:
                callId=2;
                break;
            case R.id.button3:
                callId=3;
                break;
            case R.id.button4:
                callId=4;
                break;
            case R.id.button5:
                callId=5;
                break;
            case R.id.button6:
                callId=6;
                break;
            case R.id.button7:
                callId=7;
                break;
            case R.id.button8:
                callId=8;
                break;case R.id.button9:
                callId=9;
                break;


        }
       playGame(callId,buSelected);
    }
    int Activeplayer=1;
    ArrayList<Integer> player1=new ArrayList<Integer>();
    ArrayList<Integer> player2=new ArrayList<Integer>();
    void playGame(int calid,Button selec ){

        Log.d("player",String.valueOf(calid));
        if(Activeplayer==1){
            selec.setText("X");
            selec.setBackgroundColor(Color.GREEN);
            player1.add(calid);
            Activeplayer=2;
            Autoplay();
        }
        else if(Activeplayer==2){
            selec.setText("O");
            selec.setBackgroundColor(Color.BLUE);
            player2.add(calid);
            Activeplayer=1;
        }
        selec.setEnabled(false);
        CheckWinner();
    }
    void CheckWinner(){
        int winner=-1;
        if(player1.contains(1)&&player1.contains(2)&&player1.contains(3)){
            winner=1;
        }
        if(player2.contains(1)&&player2.contains(2)&&player2.contains(3)){
            winner=2;
        }
        if(player1.contains(4)&&player1.contains(5)&&player1.contains(6)){
            winner=1;
        }
        if(player2.contains(4)&&player2.contains(5)&&player2.contains(6)){
            winner=2;
        }
        if(player1.contains(7)&&player1.contains(8)&&player1.contains(9)){
            winner=1;
        }
        if(player2.contains(7)&&player2.contains(8)&&player2.contains(9)){
            winner=2;
        }
        if(player1.contains(1)&&player1.contains(4)&&player1.contains(7)){
            winner=1;
        }
        if(player2.contains(1)&&player2.contains(4)&&player2.contains(7)){
            winner=2;
        }

        if(player1.contains(5)&&player1.contains(2)&&player1.contains(8)){
            winner=1;
        }
        if(player2.contains(5)&&player2.contains(2)&&player2.contains(8)){
            winner=2;
        }
        if(player1.contains(6)&&player1.contains(9)&&player1.contains(3)){
            winner=1;
        }
        if(player2.contains(6)&&player2.contains(9)&&player2.contains(3)){
            winner=2;
        }
        if(player1.contains(1)&&player1.contains(5)&&player1.contains(9)){
            winner=1;
        }
        if(player2.contains(1)&&player2.contains(5)&&player2.contains(9)){
            winner=2;
        }

        if(player1.contains(7)&&player1.contains(5)&&player1.contains(3)){
            winner=1;
        }
        if(player2.contains(7)&&player2.contains(5)&&player2.contains(3)){
            winner=2;
        }
         if(winner!=-1){
             if (winner == 1) {
                 Toast.makeText(this,"Player 1 is the Winner",Toast.LENGTH_LONG).show();
                 }
             if (winner == 2) {
                 Toast.makeText(this,"Player 2 is the Winner",Toast.LENGTH_LONG).show();
             }
         }
         if(player1.size()>4||player2.size()>4 &&winner==-1){
            Toast.makeText(this,"It was a tie!!",Toast.LENGTH_LONG).show();
         }
    }
    void Autoplay(){
        ArrayList<Integer> EmptyCells= new ArrayList<Integer>();

        for(int celId=0;celId<10;celId++){
            if(!(player1.contains(celId)||player2.contains(celId))){
                EmptyCells.add(celId);
            }
        }
        Random r=new Random();
        int randIndex=r.nextInt(EmptyCells.size()-0)+0;
        int CellID=EmptyCells.get(randIndex);

        Button buSelected;
        switch (CellID){

            case 1 :
                buSelected=(Button) findViewById(R.id.button);
                break;

            case 2:
                buSelected=(Button) findViewById(R.id.button2);
                break;

            case 3:
                buSelected=(Button) findViewById(R.id.button3);
                break;

            case 4:
                buSelected=(Button) findViewById(R.id.button4);
                break;

            case 5:
                buSelected=(Button) findViewById(R.id.button5);
                break;

            case 6:
                buSelected=(Button) findViewById(R.id.button6);
                break;

            case 7:
                buSelected=(Button) findViewById(R.id.button7);
                break;

            case 8:
                buSelected=(Button) findViewById(R.id.button8);
                break;

            case 9:
                buSelected=(Button) findViewById(R.id.button9);
                break;
            default:
                buSelected=(Button) findViewById(R.id.button);
                break;
        }
        playGame(CellID, buSelected);
    }
    }

